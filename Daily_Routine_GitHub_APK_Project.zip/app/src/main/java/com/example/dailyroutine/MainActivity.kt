package com.example.dailyroutine

import android.app.*
import android.os.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.*
import android.widget.*
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var box: LinearLayout
    private lateinit var prefs: android.content.SharedPreferences
    private var timer: CountDownTimer? = null
    private var remaining = 30L * 60L * 1000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("routine", MODE_PRIVATE)
        build()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 7)
    }

    fun build() {
        box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,35,28,20); setBackgroundColor(Color.WHITE) }
        val scroll = ScrollView(this); scroll.addView(box); setContentView(scroll)

        title("روتيني اليومي 🌱", 28)
        text("أنجز يومك خطوة بخطوة.", 16)

        card("🇬🇧 الإنجليزي", "30 دقيقة يوميًا") {
            val timerText = TextView(this).apply { text="30:00"; textSize=34f; gravity=17; setPadding(0,20,0,20) }
            box.addView(timerText, lp())
            val b=Button(this).apply { text="▶ بدء المؤقت" }
            b.setOnClickListener {
                timer?.cancel()
                if (remaining <= 0) remaining=30L*60*1000
                b.isEnabled=false
                timer=object:CountDownTimer(remaining,1000){
                    override fun onTick(ms:Long){ remaining=ms; timerText.text=String.format("%02d:%02d",TimeUnit.MILLISECONDS.toMinutes(ms),TimeUnit.MILLISECONDS.toSeconds(ms)%60) }
                    override fun onFinish(){ remaining=0; timerText.text="00:00"; b.isEnabled=true; Toast.makeText(this@MainActivity,"أحسنت! انتهت 30 دقيقة 🎉",Toast.LENGTH_LONG).show(); }
                }.start()
            }
            box.addView(b,lp())
        }

        card("🌙 قيام الليل", "ركعتان يوميًا") {
            val key="night_"+dayKey()
            val done=prefs.getBoolean(key,false)
            val b=Button(this).apply { text=if(done)"✅ تم اليوم" else "☑️ تم الإنجاز" }
            b.setOnClickListener { prefs.edit().putBoolean(key,true).apply(); b.text="✅ تم اليوم"; Toast.makeText(this@MainActivity,"تقبل الله منك 🤍",Toast.LENGTH_SHORT).show() }
            box.addView(b,lp())
        }

        val streak=prefs.getInt("streak",0)
        card("🔒 الخاص", "متابعة يومية خاصة") {
            text("أيام الالتزام المتتالية: $streak 🔥",20)
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            val yes=Button(this).apply{text="✅ صح"}
            val no=Button(this).apply{text="❌ غلط"}
            yes.setOnClickListener{
                val s=prefs.getInt("streak",0)+1; prefs.edit().putInt("streak",s).apply()
                Toast.makeText(this@MainActivity, if(s%7==0)"🎉 أسبوع كامل! أنت بتتغير فعلًا. استمر!" else "🔥 ممتاز! يوم جديد اتضاف لسلسلتك. كمّل.",Toast.LENGTH_LONG).show()
                build()
            }
            no.setOnClickListener{prefs.edit().putInt("streak",0).apply(); Toast.makeText(this@MainActivity,"ولا يهمك. ابدأ من جديد اليوم 💪",Toast.LENGTH_LONG).show(); build()}
            row.addView(yes, LinearLayout.LayoutParams(0,-2,1f)); row.addView(no, LinearLayout.LayoutParams(0,-2,1f)); box.addView(row,lp())
        }

        card("➕ مهام إضافية", "أضف مهمة تريد متابعتها") {
            val input=EditText(this).apply{hint="اسم المهمة"}
            val add=Button(this).apply{text="إضافة"}
            box.addView(input,lp()); box.addView(add,lp())
            val list=prefs.getStringSet("tasks",emptySet())!!.toMutableSet()
            list.forEach { task ->
                val cb=CheckBox(this).apply{text=task; textSize=17f}
                box.addView(cb,lp())
            }
            add.setOnClickListener{
                val t=input.text.toString().trim()
                if(t.isNotEmpty()){ list.add(t); prefs.edit().putStringSet("tasks",list).apply(); build() }
            }
        }

        val notify=Button(this).apply{text="🔔 تفعيل تذكير يومي"}
        notify.setOnClickListener{ scheduleReminder(); Toast.makeText(this@MainActivity,"تم تفعيل التذكير اليومي.",Toast.LENGTH_SHORT).show() }
        box.addView(notify,lp())
    }

    fun card(h:String, sub:String, content:()->Unit){
        val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(18,18,18,18)}
        val a=TextView(this).apply{text=h; textSize=22f}
        val b=TextView(this).apply{text=sub; textSize=15f}
        box.addView(a,lp()); box.addView(b,lp()); content()
        val line=TextView(this).apply{text=""; setPadding(0,12,0,12)}
        box.addView(line,lp())
    }
    fun title(s:String,z:Float){val t=TextView(this).apply{text=s;textSize=z;gravity=17;setPadding(0,0,0,12)};box.addView(t,lp())}
    fun text(s:String,z:Float){val t=TextView(this).apply{text=s;textSize=z;setPadding(0,4,0,8)};box.addView(t,lp())}
    fun lp()=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,6,0,6)}
    fun dayKey():String=java.text.SimpleDateFormat("yyyyMMdd",Locale.US).format(Date())

    fun scheduleReminder(){
        val am=getSystemService(ALARM_SERVICE) as AlarmManager
        val i=Intent(this, ReminderReceiver::class.java)
        val pi=PendingIntent.getBroadcast(this,1,i,PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val cal=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,18);set(Calendar.MINUTE,0);set(Calendar.SECOND,0)}
        if(cal.timeInMillis<System.currentTimeMillis())cal.add(Calendar.DATE,1)
        am.setRepeating(AlarmManager.RTC_WAKEUP,cal.timeInMillis,AlarmManager.INTERVAL_DAY,pi)
    }
}
class ReminderReceiver:BroadcastReceiver(){
    override fun onReceive(c:Context,i:Intent){
        val nm=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel("daily","التذكيرات",NotificationManager.IMPORTANCE_DEFAULT))
        val n=Notification.Builder(c,"daily").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("روتيني اليومي").setContentText("حان وقت مراجعة مهامك اليومية 🌱").build()
        nm.notify(10,n)
    }
}
